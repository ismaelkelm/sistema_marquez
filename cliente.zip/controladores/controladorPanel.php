<?php
// Controlador para el panel de administración

function mostrarPanel() {
    // Implementar lógica para mostrar el panel
}
?>
