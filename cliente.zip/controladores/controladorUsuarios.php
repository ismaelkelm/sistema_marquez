<?php
// Controlador para la gestión de usuarios

function registrarUsuario($nombre, $email, $contraseña) {
    // Implementar lógica para registrar un nuevo usuario
}

function obtenerUsuarios() {
    // Implementar lógica para obtener usuarios
}
?>
