<?php
return array (
  'Administrador' => 
  array (
    'Accesorios' => 'on',
    'Clientes' => 'on',
    'Detalle Facturas' => 'on',
    'Detalle Reparaciones' => 'on',
    'Dispositivos' => 'on',
    'Empleados' => 'on',
    'Facturas' => 'on',
    'Movimientos' => 'on',
    'Movimientos Financieros' => 'on',
    'Notificaciones' => 'on',
    'Pagos' => 'on',
    'Password Resets' => 'on',
    'Pedidos de Reparación' => 'on',
    'Piezas y Componentes' => 'on',
    'Proveedores' => 'on',
    'Recibos' => 'on',
    'Reparaciones' => 'on',
    'Roles' => 'on',
    'Técnicos' => 'on',
    'Tickets' => 'on',
    'Usuarios' => 'on',
    'Ventas Accesorios' => 'on',
  ),
  'Administrativo' => 
  array (
    'Accesorios' => 'on',
    'Clientes' => 'on',
    'Detalle Facturas' => 'on',
    'Dispositivos' => 'on',
    'Empleados' => 'on',
    'Facturas' => 'on',
    'Notificaciones' => 'on',
    'Pedidos de Reparación' => 'on',
    'Proveedores' => 'on',
    'Recibos' => 'on',
    'Técnicos' => 'on',
    'Tickets' => 'on',
    'Ventas Accesorios' => 'on',
  ),
  'Tecnico' => 
  array (
    'Accesorios' => 'on',
    'Clientes' => 'on',
    'Detalle Reparaciones' => 'on',
    'Dispositivos' => 'on',
    'Notificaciones' => 'on',
    'Pedidos de Reparación' => 'on',
    'Reparaciones' => 'on',
  ),
  'Cliente' => 
  array (
    'Clientes' => 'on',
    'Pedidos de Reparación' => 'on',
    'Ventas Accesorios' => 'on',
  ),
);
?>